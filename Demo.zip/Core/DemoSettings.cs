using JmcModLib.Config;
using JmcModLib.Config.UI;
using JmcModLib.Utils;

namespace JmcModLibDemo.Core;

public enum DemoColorTheme
{
    Classic,
    Gold,
    Emerald,
    Crimson
}

public static class DemoSettings
{
    private const string DirectWriteGroup = "1. 无回调直接写值";
    private const string CallbackGroup = "2. 带回调处理副作用";
    private const string TextGroup = "3. 文本输入";
    private const string DropdownGroup = "4. 下拉菜单";
    private const string NumericGroup = "5. 数值控件";
    private const string ButtonGroup = "6. 按钮";

    private static int propertyBackedLevel = 3;

    public static int LastDirectSetterValue { get; private set; } = propertyBackedLevel;

    public static string LastCallbackMessage { get; private set; } = "尚未触发回调";

    public static int ButtonClickCount { get; private set; }

    /// <summary>
    /// 最普通的字段写法：不需要 OnChanged，UI 修改时 JmcModLib 会直接 SetValue 到这个 static 字段。
    /// </summary>
    [UIToggle]
    [Config(
        "直接修改 bool 字段",
        group: DirectWriteGroup,
        Description = "不写 onChanged。开关变化后，这个 static 字段会被 JmcModLib 直接改掉并保存。",
        Key = "direct.enable_feature",
        Order = 10)]
    public static bool DirectBoolField = true;

    /// <summary>
    /// 属性也可以无回调直接写；这里的 setter 只是为了证明 UI 确实会直接调用属性 setter。
    /// </summary>
    [UIIntSlider(0, 10)]
    [Config(
        "直接修改 int 属性",
        group: DirectWriteGroup,
        Description = "同样不写 onChanged。拖动滑条会直接调用属性 setter，并在日志里记录 setter 收到的值。",
        Key = "direct.property_level",
        Order = 20)]
    public static int PropertyBackedLevel
    {
        get => propertyBackedLevel;
        set
        {
            propertyBackedLevel = value;
            LastDirectSetterValue = value;
            ModLogger.Info($"PropertyBackedLevel setter => {value}");
        }
    }

    [UISlider(0.5, 2.0, 0.1)]
    [Config(
        "带回调的缩放倍率",
        onChanged: nameof(OnCallbackScaleChanged),
        group: CallbackGroup,
        Description = "只有需要刷新缓存、重建 UI、通知游戏对象时才需要 onChanged。",
        Key = "callback.scale",
        Order = 10)]
    public static double CallbackScale = 1.0;

    [UIFloatSlider(0f, 1f, decimalPlaces: 2)]
    [Config(
        "带回调的透明度",
        onChanged: nameof(OnCallbackAlphaChanged),
        group: CallbackGroup,
        Description = "这个示例会在回调里写日志。实际 MOD 可在这里刷新界面、清缓存或重算状态。",
        Key = "callback.alpha",
        Order = 20)]
    public static float CallbackAlpha = 0.75f;

    [UIInput(32)]
    [Config(
        "单行文本输入",
        group: TextGroup,
        Description = "UIInput 目前会渲染为文本输入框，提交或失焦时保存。",
        Key = "text.single_line",
        Order = 10)]
    public static string SingleLineText = "Hello JmcModLib";

    [UIInput(160, multiline: true)]
    [Config(
        "多行文本声明",
        group: TextGroup,
        Description = "这里演示 multiline 元数据。当前游戏内配置桥接仍以单行输入控件承载。",
        Key = "text.multiline_declared",
        Order = 20)]
    public static string MultilineDeclaredText = "line one / line two";

    [UIDropdown]
    [Config(
        "枚举下拉",
        group: DropdownGroup,
        Description = "枚举类型不传参数时会自动使用全部枚举值。",
        Key = "dropdown.enum_theme",
        Order = 10)]
    public static DemoColorTheme EnumTheme = DemoColorTheme.Gold;

    [UIDropdown("Compact", "Normal", "Large")]
    [Config(
        "字符串下拉",
        group: DropdownGroup,
        Description = "字符串下拉需要在 UIDropdown 里列出候选项。",
        Key = "dropdown.string_size",
        Order = 20)]
    public static string StringDropdown = "Normal";

    [UIDropdown(nameof(DemoColorTheme.Crimson))]
    [Config(
        "枚举下拉排除项",
        group: DropdownGroup,
        Description = "枚举模式下 UIDropdown 参数会被当作排除项，这里隐藏 Crimson。",
        Key = "dropdown.enum_exclude",
        Order = 30)]
    public static DemoColorTheme EnumThemeWithoutCrimson = DemoColorTheme.Emerald;

    [UIIntSlider(0, 100)]
    [Config(
        "整数滑条",
        group: NumericGroup,
        Description = "UIIntSlider 只支持 int。",
        Key = "numeric.int_slider",
        Order = 10)]
    public static int IntSlider = 40;

    [UIFloatSlider(-10f, 10f, decimalPlaces: 1)]
    [Config(
        "浮点滑条",
        group: NumericGroup,
        Description = "UIFloatSlider 只支持 float，decimalPlaces 控制步进和显示精度。",
        Key = "numeric.float_slider",
        Order = 20)]
    public static float FloatSlider = 2.5f;

    [UISlider(0.0, 1.0, 0.05)]
    [Config(
        "通用数字滑条 double",
        group: NumericGroup,
        Description = "UISlider 可用于 int/float/double/decimal 等数字类型。",
        Key = "numeric.double_slider",
        Order = 30)]
    public static double DoubleSlider = 0.5;

    [Config(
        "无 UI Attribute 的数字",
        group: NumericGroup,
        Description = "没有 UI Attribute 时，数字会走基础 SpinBox 回退控件。",
        Key = "numeric.spinbox_fallback",
        Order = 40)]
    public static int SpinBoxFallback = 7;

    [UIToggle]
    [Config(
        "需要重启的开关",
        group: NumericGroup,
        Description = "RestartRequired 会在配置项下面显示重启提示。",
        Key = "numeric.restart_required_toggle",
        RestartRequired = true,
        Order = 50)]
    public static bool RestartRequiredToggle = false;

    [UIButton("Attribute 按钮", "执行", ButtonGroup, Order = 10)]
    public static void RunAttributeButton()
    {
        ButtonClickCount++;
        ModLogger.Info($"[UIButton] 按钮被点击，累计次数：{ButtonClickCount}");
    }

    public static void RunManualButton()
    {
        ButtonClickCount++;
        ModLogger.Info($"RegisterButton 手动按钮被点击，累计次数：{ButtonClickCount}");
    }

    private static void OnCallbackScaleChanged(double value)
    {
        LastCallbackMessage = $"Scale callback => {value:0.0}";
        ModLogger.Info(LastCallbackMessage);
    }

    private static void OnCallbackAlphaChanged(float value)
    {
        LastCallbackMessage = $"Alpha callback => {value:0.00}";
        ModLogger.Info(LastCallbackMessage);
    }
}
