namespace JmcModLibDemo.Core;

public static class VersionInfo
{
    public const string Name = "JmcModLibDemo";
    public const string Version = "1.0.0";

    public static string Tag => $"[{Name} v{Version}]";
}
