using Godot;
using JmcModLibDemo.Core;
using JmcModLib.Utils;
using MegaCrit.Sts2.Core.Modding;
using ModVersionInfo = JmcModLibDemo.Core.VersionInfo;

namespace JmcModLibDemo;

[ModInitializer(nameof(Initialize))]
public partial class MainFile : Node
{
    public static void Initialize()
    {
        JmcModLib.Core.ModRegistry.Register(true, ModVersionInfo.Name, ModVersionInfo.Name, ModVersionInfo.Version)?
            .RegisterLogger(uIFlags: LogConfigUIFlags.All)
            .RegisterButton(out _, "手动注册按钮", DemoSettings.RunManualButton, "执行", group: "6. 按钮", order: 5)
            .UseConfig()
            .Done();

        ModLogger.Info("======================================");
        ModLogger.Info("JmcModLib Demo Mod 正在启动...");
        ModLogger.Info("这个 MOD 只用于展示 JmcModLib 设置 UI 和配置扫描用法。");
        ModLogger.Info("======================================");
    }
}
